# Hello, reader!
This is the main storage of [www.knigopis.com](http://www.knigopis.com) - the registry of read books.
To add your book use www-site. All changes are committed and synchronized with this git repository.
Do not use pull requests to make changes here.


## Latest books with notes
* Дом на краю ночи ~ [Sky](users/118/118049897850017649660-google)<sup>36</sup>
    > Такие семейные саги, где описывается жизнь нескольких поколений, мне читать еще не приходилось, интересно. Итальянский колорит тоже добавляет разнообразия.

* Остаться в живых. Психология поведения в экстремальных ситуациях ~ [Ник Литвинов](users/241/241974816-vkontakte)<sup>113</sup>
    > В процессе
    > 
    > https://www.ozon.ru/context/detail/id/27071402/

* Между Огней ~ [Chiffi](users/105/105831994080785626680-google)<sup>26</sup>
    > Продолжение После Огня.  
    > Очень жалко Лисенка

* Превращение ~ [idsimonbell](users/380/380554090-vkontakte)<sup>33</sup>

* После Огня ~ [Chiffi](users/105/105831994080785626680-google)<sup>25</sup>

* Эрик (цикл Волшебники и герои, часть 4) ~ [SMedgaus](users/162/162444669-vkontakte)<sup>8</sup>

* От слов к делу! ~ [Ник Литвинов](users/241/241974816-vkontakte)<sup>112</sup>

* Боги, святилища, обряды Японии. Энциклопедия Синто ~ [Ник Литвинов](users/241/241974816-vkontakte)<sup>111</sup>

* Вафли по-шпионски ~ [Chiffi](users/105/105831994080785626680-google)<sup>24</sup>

* Вино из одуванчиков ~ [joan789](users/240/2401650-vkontakte)<sup>60</sup>


_More notes [here](latest_books_with_notes.md)._


## Latest users
[Sky](users/118/118049897850017649660-google)<sup>36</sup> 
[Oksana](users/100/100001603844736-facebook)<sup>0</sup> 
[arisss](users/839/8399226-vkontakte)<sup>0</sup> 
[Ник Литвинов](users/241/241974816-vkontakte)<sup>113</sup> 
[okfine](users/209/209723-vkontakte)<sup>3</sup> 
[Chiffi](users/105/105831994080785626680-google)<sup>26</sup> 
[Lost in Frost](users/103/103293621948650602575-google)<sup>90</sup> 
[Andrey](users/482/4823577-vkontakte)<sup>0</sup> 
[idsimonbell](users/380/380554090-vkontakte)<sup>33</sup> 
[annushkash92](users/159/159468103-vkontakte)<sup>0</sup> 
[SMedgaus](users/162/162444669-vkontakte)<sup>8</sup> 
[Gregor Bjdantukevich](users/102/102763689513347752702-google)<sup>1</sup> 
[Clémence](users/215/215227771-vkontakte)<sup>2</sup> 
[Eji_tyan](users/235/2352103981-twitter)<sup>31</sup> 
[joan789](users/240/2401650-vkontakte)<sup>60</sup> 
[borodach](users/157/15706320-vkontakte)<sup>105</sup> 
[inna.besprozvannykh](users/733/73323849-yandex)<sup>28</sup> 
[forgame904](users/103/103869594497189251620-google)<sup>0</sup> 
[silin_mihail](users/133/1335076-vkontakte)<sup>1</sup> 
[Hikari](users/192/192185074-vkontakte)<sup>0</sup> 
[develchip](users/852/85203415-vkontakte)<sup>62</sup> 
[ohsubbotina](users/556/556889019-twitter)<sup>0</sup> 
[Яна](users/200/20033623-vkontakte)<sup>0</sup> 
[sad little panda](users/188/1882525281990290-facebook)<sup>29</sup> 
[Элла](users/100/1002037069862545-facebook)<sup>4</sup> 
[***Тамара***](users/311/3114181641539446926-mailru)<sup>0</sup> 
[Лорд Пудинг](users/112/112214463787387089052-google)<sup>0</sup> 
[irina sarafova](users/143/1431088546976250-facebook)<sup>1</sup> 
[ODINSY](users/100/100978570902186865324-google)<sup>54</sup> 
[abzagir4ik](users/362/3621623-vkontakte)<sup>88</sup> 


_03.08.2017 05:11:10_
