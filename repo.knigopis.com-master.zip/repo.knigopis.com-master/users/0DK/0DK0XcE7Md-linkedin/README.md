# Список прочитанных книг пользователя [keenstone](https://www.linkedin.com/pub/vladimir-povyshev/34/482/aa2)<sup>1</sup>
---

## 2015

### тест1
автортест
> [2015-05-01] тесттесттест



