# Список прочитанных книг пользователя [ann.ryzhkova](https://www.facebook.com/ann.ryzhkova)<sup>2</sup>
---

## 2015

### About Face 3
Алан Купер
> [-30] 


> 8%



