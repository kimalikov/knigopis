# Список прочитанных книг пользователя [nemph1s](https://www.facebook.com/app_scoped_user_id/100001687576967/)<sup>44</sup>
---

## 2016

### Used In Evidence
Frederick Forsyth
> [2016-02-22] 


### The Beauty and the Beast
Jeanne Marie Leprince De Beaumont
> [2016-02-22] 


### The Adventures of Tom Sawyer
Mark Twain
> [2016-02-22] 


### Peter Pan
J. M. Barrie
> [2016-02-17] 


### Journey to the Center of the Earth
Jules Verne
> [2016-02-16] 


### Home for Christmas
Andrea M. Hutchinson
> [2016-02-16] 3 girls (Harminda, Vanessa, Shauna), London, drug dillers, case of money


### The Adventures in The Grasslands
John Bookwarm
> [2016-02-15] 


### The Adventure of the Blue Carbuncle
Conan Doyle
> [2016-02-15] 


### A Scandal In Bohemia
Conan Doyle
> [2016-02-12] 


### Puss in boots
Charles Perrault
> [2016-02-11] 


### Rich Man, Poor Man
T.C. Jupp
> [2016-02-11] 


### Ligeia
Edgar Allan Poe
> [2016-02-11] 


### In The Dark
E. Nesbit
> [2016-02-10] 


### How is Your Mother
Simon Brett
> [2016-02-09] 


### Ali Baba and the Forty Thieves
Antoine Galland
> [2016-02-09] 


### Cinderella
Ruth Hobart
> [2016-02-08] 


### At the Old Swimming Hole
Sara Paretsky
> [2016-02-08] 


### Death Wish
Lawrence Block
> [2016-02-08] 


### Berenice
Edgar Allan Poe
> [2016-02-07] 


### Woodrow Wilson Tie
Patricia Highsmith
> [2016-02-07] 


### A Descent Into The Maelstrom
Edgar Allan Poe
> [2016-02-07] 


### The Black Cat
Edgar Allan Poe
> [2016-02-04] 


### The Yellow Face
Conan Doyle
> [2016-02-04] 


### The pit and pendulum
Edgar Allan Poe
> [2016-02-04] 


### Three is a Lucky Number
Margery Allingham
> [2016-02-02] 


### The Speckled Band
Conan Doyle
> [2016-02-01] 


### The Fall of the House of Usher
Edgar Allan Poe
> [2016-02-01] 


### The Absence of Emily
Jack Ritchie
> [2016-01-29] 


### The Facts in The Case of Mr Valdemar
Edgar Allan Poe
> [2016-01-29] 


### The True Story of Pocahontas
Kelly Reinhart
> [2016-01-29] 


### Slowly, Slowly in the Wind
Patricia Highsmith
> [2016-01-28] 


### Sleeping Beauty
Charles Parrault
> [2016-01-28] 


### The House On The Hill
Elizabeth Laird
> [2016-01-28] "I was a fool", he thought. "Maria never loved me, how stupid I was" Maria is beautiful but she is hard and cold, like her mother. I loved Maria's beauty, but never loved Maria.


### The Singalman
Charles Dickens
> [2016-01-28] 


### The Masque of the Red Death
Edgar Allan Poe
> [2016-01-28] 


### Aladdin
Ruth Hobart
> [2016-01-28] 


### The Five Orange Pips
Conan Doyle
> [2016-01-27] 


### The oblong box
Edgar Allan Poe
> [2016-01-27] 


### The Heroine
Patricia Highsmith
> [2016-01-27] 


### The Collector
Peter Viney
> [2016-01-26] 


### 35 кило надежды
Гавальда Анна
> [2016-01-25] 


### Завтрак у Тиффани
Капоте Трумен
> [2016-01-25] 


### Старик и море
Эрнест Хемингуей
> [2016-01-22] Старик и рыба


### Вспоминая моих грустных шлюх
Габриэль Гарсиа Маркес
> [2016-01-20] Незаметно для себя, я начал соопереживать главному герою, когда он влюбился как мальчишка, чисто, пламенно, безпамятно. И только после этого его жизнь заиграла новыми красками. Может именно по этому мне этот старик показался настолько близким по духу.



