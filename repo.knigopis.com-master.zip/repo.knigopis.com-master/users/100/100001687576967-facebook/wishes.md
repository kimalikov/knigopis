# Список к прочтению пользователя [nemph1s](https://www.facebook.com/app_scoped_user_id/100001687576967/)
---

### `100` The Hound of the Baskervilles
Arthur Conan Doyle

### `100` For Whom the Bell Tolls
Ernest Hemingway

### `100` Misery
Stephen King

### `95` Hercule Poirot
Agatha Christie

### `85` The Picture of Dorian Gray
Oscar Wilde

### `85` The Jungle Book
Rudyard Kipling

### `80` The Stories of Ray Bradbury
Ray Bradbury

### `80` Hitchhiker’s Guide to the Galaxy
Douglas Adams

### `75` Best Short Stories
O. Henry

### `75` Cat’s Cradle
Kurt Vonnegut

### `75` Three Men in a Boat
Jerome K. Jerome

### `50` Green Eggs and Ham
Dr. Seuss

### `50` The Giving Tree
Shel Silverstein

### `50` Theatre
Somerset Maugham

