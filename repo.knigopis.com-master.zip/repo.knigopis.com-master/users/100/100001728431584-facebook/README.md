# List of books read by [Krozy](https://www.facebook.com/app_scoped_user_id/100001728431584/)<sup>1</sup>
---

## 2017

### Gghh
Nnnn



