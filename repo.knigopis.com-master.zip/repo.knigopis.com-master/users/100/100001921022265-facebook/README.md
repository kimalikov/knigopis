# List of books read by Yevgen<sup>1</sup>
---

## 2008

### Одиночество в Сети
Януш Леон Вишневский



