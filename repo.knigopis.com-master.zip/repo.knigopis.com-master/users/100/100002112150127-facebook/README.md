# Список прочитанных книг пользователя [nadina.bragi](https://www.facebook.com/nadina.bragi)<sup>1</sup>
---

## 2015

### Манипуляции
Кара Мурза
> [2015-01-26] 



